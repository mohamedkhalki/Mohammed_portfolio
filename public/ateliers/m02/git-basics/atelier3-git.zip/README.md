

\# Atelier 3 - Les bases de Git



Projet pratique pour apprendre les commandes fondamentales de Git.



\## Objectifs

\- Initialiser un dépôt Git

\- Ajouter et modifier des fichiers

\- Créer des commits

\- Consulter l'historique des modifications



\## Technologies

\- HTML

\- CSS

\- Git



\## Auteur

Mohammed Khalki



