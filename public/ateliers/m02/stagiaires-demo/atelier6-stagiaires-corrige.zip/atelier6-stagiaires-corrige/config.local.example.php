<?php
// Copy to config.local.php (never commit this file to GitHub).
// For production, prefer the environment variables described in README.md.
return [
  'host' => 'YOUR_AIVEN_HOST',
  'port' => 13397,
  'database' => 'atelier6_stagiaires',
  'username' => 'avnadmin',
  'password' => 'YOUR_NEW_AIVEN_PASSWORD',
  'cloud_name' => 'YOUR_CLOUDINARY_CLOUD_NAME',
  'api_key' => 'YOUR_CLOUDINARY_API_KEY',
  'api_secret' => 'YOUR_NEW_CLOUDINARY_API_SECRET',
  'admin_password' => 'YOUR_STRONG_ADMIN_PASSWORD',
];
