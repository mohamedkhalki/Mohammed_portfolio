<?php
declare(strict_types=1);

function a6Setting(string $key, string $fallback = ''): string
{
    $value = getenv($key);
    if ($value !== false && $value !== '') return (string)$value;
    // Optional development-only configuration stored outside the public/ directory.
    static $local = null;
    if ($local === null) {
        $path = dirname(__DIR__) . '/config.local.php';
        $local = is_file($path) ? require $path : [];
        if (!is_array($local)) $local = [];
    }
    $aliases = [
        'DB_HOST'=>'host', 'DB_PORT'=>'port', 'DB_NAME'=>'database',
        'DB_USER'=>'username', 'DB_PASSWORD'=>'password',
        'CLOUDINARY_CLOUD_NAME'=>'cloud_name',
        'CLOUDINARY_API_KEY'=>'api_key', 'CLOUDINARY_API_SECRET'=>'api_secret',
        'ATELIER6_ADMIN_PASSWORD'=>'admin_password',
    ];
    $localKey = $aliases[$key] ?? $key;
    return isset($local[$localKey]) ? (string)$local[$localKey] : $fallback;
}

function a6AdminAuthorized(): bool
{
    // Development shortcut only for requests received over the loopback interface.
    $remote = $_SERVER['REMOTE_ADDR'] ?? '';
    if (a6Setting('ATELIER6_LOCAL_DEV') === '1' && in_array($remote, ['127.0.0.1','::1'], true)) return true;
    $secret = a6Setting('ATELIER6_ADMIN_PASSWORD');
    if ($secret === '') return false;
    $user = (string)($_SERVER['PHP_AUTH_USER'] ?? '');
    $password = (string)($_SERVER['PHP_AUTH_PW'] ?? '');
    if ((!$user || !$password) && preg_match('/^Basic\s+(.+)$/i', (string)($_SERVER['HTTP_AUTHORIZATION'] ?? ''), $matches)) {
        $decoded = base64_decode($matches[1], true);
        if (is_string($decoded) && str_contains($decoded, ':')) [$user, $password] = explode(':', $decoded, 2);
    }
    return $user === 'admin' && hash_equals($secret, $password);
}

function a6RequireAdmin(): void
{
    if (a6AdminAuthorized()) return;
    header('WWW-Authenticate: Basic realm="Atelier6"');
    a6Json(401, ['error'=>'Accès administrateur requis.']);
}

function a6Json(int $status, array $payload): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function a6Database(): PDO
{
    $required = ['DB_HOST','DB_NAME','DB_USER','DB_PASSWORD'];
    foreach ($required as $key) if (a6Setting($key) === '') throw new RuntimeException('Configuration MySQL manquante.');
    $sslCa = a6Setting('DB_SSL_CA', dirname(__DIR__) . '/certs/ca.pem');
    if (!is_file($sslCa) || !is_readable($sslCa)) throw new RuntimeException('Certificat MySQL absent.');
    $host = a6Setting('DB_HOST');
    $port = (int)a6Setting('DB_PORT', '3306');
    $name = a6Setting('DB_NAME');
    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
    return new PDO($dsn, a6Setting('DB_USER'), a6Setting('DB_PASSWORD'), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_SSL_CA => $sslCa,
        PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT => true,
    ]);
}

function a6CloudUpload(array $photo): string
{
    foreach (['CLOUDINARY_CLOUD_NAME', 'CLOUDINARY_API_KEY', 'CLOUDINARY_API_SECRET'] as $key)
        if (a6Setting($key) === '') throw new RuntimeException('Configuration Cloudinary manquante.');
    if (($photo['error'] ?? -1) !== UPLOAD_ERR_OK || !is_uploaded_file((string)($photo['tmp_name'] ?? '')))
        throw new InvalidArgumentException('La photo est obligatoire.');
    $size = (int)($photo['size'] ?? 0);
    if ($size < 1 || $size > 3*1024*1024) throw new InvalidArgumentException('Photo : 3 Mo maximum.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($photo['tmp_name']);
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if (!isset($allowed[$mime]) || @getimagesize($photo['tmp_name']) === false)
        throw new InvalidArgumentException('Photo JPG, PNG ou WEBP uniquement.');
    $endpoint = 'https://api.cloudinary.com/v1_1/'.rawurlencode(a6Setting('CLOUDINARY_CLOUD_NAME')).'/image/upload';
    $ch = curl_init($endpoint);
    if ($ch === false) throw new RuntimeException('Erreur initialisation Cloudinary.');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
        CURLOPT_USERPWD => a6Setting('CLOUDINARY_API_KEY') . ':' . a6Setting('CLOUDINARY_API_SECRET'),
        CURLOPT_POSTFIELDS => [
            'file' => new CURLFile($photo['tmp_name'], $mime, 'stagiaire.'.$allowed[$mime]),
            'folder' => 'atelier6_stagiaires',
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 35,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $errno = curl_errno($ch);
    curl_close($ch);
    if ($body === false || $http < 200 || $http >= 300)
        throw new RuntimeException("Cloudinary HTTP {$http} / cURL {$errno}");
    $json = json_decode($body, true);
    $url = $json['secure_url'] ?? '';
    if (!is_string($url) || !str_starts_with($url, 'https://res.cloudinary.com/'))
        throw new RuntimeException('URL Cloudinary invalide.');
    return $url;
}
