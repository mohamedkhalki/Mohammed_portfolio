// Admin password is kept only in this page's memory, never in the URL or localStorage.
let adminPassword = '';
async function apiRequest(path, options = {}) {
  const headers = new Headers(options.headers || {});
  if (adminPassword) headers.set('Authorization', 'Basic ' + btoa('admin:' + adminPassword));
  let response = await fetch(path, {...options, headers, cache: 'no-store'});
  if (response.status === 401 && !adminPassword) {
    const password = window.prompt('Mot de passe administrateur (annuler pour rester en démonstration) :');
    if (password === null) return {cancelled:true};
    adminPassword = password;
    headers.set('Authorization', 'Basic ' + btoa('admin:' + adminPassword));
    response = await fetch(path, {...options, headers, cache: 'no-store'});
  }
  if (response.status === 401) adminPassword = '';
  let data;
  try { data = await response.json(); } catch { data = {error:'Réponse serveur invalide.'}; }
  return {status:response.status, data};
}
function setMessage(element, message) { element.textContent = message; }
const form = document.getElementById('form');
if (form) {
  const message = document.getElementById('msg');
  const button = document.getElementById('btn');
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const photo = form.elements.photo.files[0];
    if (!photo || photo.size > 3*1024*1024 || !['image/jpeg','image/png','image/webp'].includes(photo.type)) {
      setMessage(message, 'Choisissez une image JPG, PNG ou WEBP (max 3 Mo).'); return;
    }
    button.disabled = true; setMessage(message, 'Envoi en cours…');
    try {
      const result = await apiRequest('/api/inscrire.php', {method:'POST', body:new FormData(form)});
      if (result.cancelled) setMessage(message,'Inscription annulée. Les données n’ont pas été envoyées.');
      else if (result.data.success) { setMessage(message,'Stagiaire enregistré avec succès !'); form.reset(); }
      else setMessage(message, result.data.error || 'Inscription impossible.');
    } catch { setMessage(message,'Erreur de connexion. Vérifiez que le serveur PHP fonctionne.'); }
    finally { button.disabled = false; }
  });
}
const listButton = document.getElementById('load');
if (listButton) {
  const message = document.getElementById('msg');
  const container = document.getElementById('liste');
  listButton.addEventListener('click', async () => {
    listButton.disabled=true; setMessage(message,'Chargement…');
    try {
      const result=await apiRequest('/api/liste.php');
      if (result.cancelled) {setMessage(message,'La liste privée n’a pas été chargée.'); return;}
      if (!Array.isArray(result.data.stagiaires)) {setMessage(message,result.data.error || 'Chargement impossible.');return;}
      container.replaceChildren();
      for (const s of result.data.stagiaires) {
        const card = document.createElement('article'); card.className='person';
        if (typeof s.photo_url==='string' && /^https:\/\/res\.cloudinary\.com\//.test(s.photo_url)) {
          const img=document.createElement('img'); img.src=s.photo_url; img.alt='Photo du stagiaire'; img.loading='lazy'; card.appendChild(img);
        } else {
          const initial=document.createElement('div'); initial.className='initial'; initial.textContent=(s.prenom||'?').slice(0,1);card.appendChild(initial);
        }
        const name=document.createElement('strong'); name.textContent=`${s.prenom||''} ${s.nom||''}`;
        const city=document.createElement('small'); city.textContent=s.ville||'';
        card.append(name,city); container.appendChild(card);
      }
      setMessage(message, `${result.data.stagiaires.length} stagiaire(s) chargé(s).`);
    } catch {setMessage(message,'Erreur de connexion.');}
    finally {listButton.disabled=false;}
  });
}
