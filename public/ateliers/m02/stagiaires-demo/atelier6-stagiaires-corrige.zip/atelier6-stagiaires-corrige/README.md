# Atelier 6 — Gestion des stagiaires

Projet **PHP 8.3+**, **MySQL Aiven** (SSL) et **Cloudinary**. Cette édition est une correction du dossier fourni : les noms de colonnes correspondent au schéma réel (`photo_url`, `created_at`), les erreurs d'insert sont corrigées, et l'inscription / la liste privées sont protégées.

## Installation locale sous Windows (WAMP)

1. Extraire ce ZIP sur le Bureau et ouvrir CMD dans le dossier `atelier6-stagiaires-corrige`.
2. Copier `config.local.example.php` vers `config.local.php`, puis remplir les **nouveaux** identifiants MySQL / Cloudinary et un mot de passe administrateur. Ce fichier est ignoré par Git ; ne jamais l'envoyer dans un chat.
3. Un certificat CA public Aiven est inclus dans `certs/ca.pem`. Si votre instance Aiven change, remplacez ce fichier avec la CA téléchargée depuis l'instance concernée.
4. Utiliser un PHP avec `pdo_mysql`, `curl` et `fileinfo` activés, et un bundle CA HTTPS pour cURL (`curl.cainfo` dans `php.ini`).
5. Lancer :

```cmd
cd /d "%USERPROFILE%\Desktop\atelier6-stagiaires-corrige"
"C:\wamp64\bin\php\php8.3.28\php.exe" -S 127.0.0.1:8000 -t public router.php
```

Ouvrir `http://127.0.0.1:8000`. Le formulaire est **modifiable** ; lors du premier envoi, un mot de passe administrateur est demandé. Pour les essais locaux seulement, vous pouvez lancer `set ATELIER6_LOCAL_DEV=1` **avant** le serveur : l'administration fonctionne alors uniquement via la boucle locale sans saisie du mot de passe.

## Déploiement

Le frontend est dans `public/`, les scripts dans `api/`, le certificat public dans `certs/`. Sur Vercel, ajoutez ces variables d'environnement dans **Settings > Environment Variables**, puis redéployez :

- `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`
- `ATELIER6_ADMIN_PASSWORD` (mot de passe long, unique)

N'utilisez **jamais** `ATELIER6_LOCAL_DEV=1` sur Vercel. Le runtime PHP de Vercel (`vercel-php@0.7.3`) est une intégration tierce ; il reste nécessaire de tester la compatibilité sur votre déploiement réel. Le site public peut afficher les pages et permettre de remplir le formulaire, mais les opérations sur les données sont protégées.

## Base de données (déjà créée chez vous)

Le fichier `schema.sql` illustre le schéma utilisé. Ne recréez pas la table si elle existe déjà dans Aiven.

## Sécurité

**Révoquer/renouveler** les identifiants Aiven et le secret API Cloudinary déjà partagés auparavant. Aucun secret, dossier `.git`, historique Git, fichier `.env` ou configuration privée n'est inclus dans ce ZIP. Les photos hébergées sur Cloudinary sont potentiellement accessibles via leur URL ; utiliser des photos autorisées et des données fictives pour les démonstrations.

Les tests de syntaxe et les vérifications locales ne prouvent pas la connectivité réelle au compte Aiven ou Cloudinary ; renseignez les nouvelles valeurs d'abord.
