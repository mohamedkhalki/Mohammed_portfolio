<?php
declare(strict_types=1);
require __DIR__ . '/../config/app.php';
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') a6Json(405, ['error'=>'Méthode non autorisée.']);
a6RequireAdmin();
if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 4*1024*1024) a6Json(413, ['error'=>'Envoi trop volumineux.']);
$nom = trim((string)($_POST['nom'] ?? ''));
$prenom = trim((string)($_POST['prenom'] ?? ''));
$ville = trim((string)($_POST['ville'] ?? ''));
foreach ([$nom, $prenom, $ville] as $text) {
    if ($text === '' || (function_exists('mb_strlen') ? mb_strlen($text) : strlen($text)) > 100)
        a6Json(400, ['error'=>'Veuillez compléter les champs (100 caractères maximum).']);
}
if (!isset($_FILES['photo'])) a6Json(400, ['error'=>'Veuillez sélectionner une photo.']);
try {
    // Check the database BEFORE uploading to avoid abandoned Cloudinary images on connection errors.
    $pdo = a6Database();
    $url = a6CloudUpload($_FILES['photo']);
    $stmt = $pdo->prepare('INSERT INTO stagiaires (nom, prenom, ville, photo_url) VALUES (:nom, :prenom, :ville, :photo_url)');
    $stmt->execute(['nom'=>$nom, 'prenom'=>$prenom, 'ville'=>$ville, 'photo_url'=>$url]);
    a6Json(201, ['success'=>true]);
} catch (InvalidArgumentException $e) {
    a6Json(400, ['error'=>$e->getMessage()]);
} catch (Throwable $e) {
    error_log('Atelier6 inscription: ' . $e->getMessage());
    a6Json(500, ['error'=>'Enregistrement impossible. Vérifiez la configuration du serveur.']);
}
