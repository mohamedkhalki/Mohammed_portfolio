<?php
declare(strict_types=1);
require __DIR__ . '/../config/app.php';
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') a6Json(405, ['error'=>'Méthode non autorisée.']);
a6RequireAdmin();
try {
    $query = a6Database()->query('SELECT id, nom, prenom, ville, photo_url, created_at FROM stagiaires ORDER BY id DESC LIMIT 50');
    a6Json(200, ['stagiaires'=>$query->fetchAll()]);
} catch (Throwable $e) {
    error_log('Atelier6 listing: ' . $e->getMessage());
    a6Json(500, ['error'=>'Liste indisponible. Vérifiez la configuration MySQL.']);
}
