<?php
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
if ($path === '/api/inscrire.php') { require __DIR__ . '/api/inscrire.php'; return true; }
if ($path === '/api/liste.php') { require __DIR__ . '/api/liste.php'; return true; }
if ($path === '/api' || str_starts_with($path, '/api/')) { http_response_code(404); return true; }
if ($path === '/') { require __DIR__ . '/public/index.html'; return true; }
$file = realpath(__DIR__ . '/public' . $path);
$root = realpath(__DIR__ . '/public');
if ($file && $root && str_starts_with($file, $root.DIRECTORY_SEPARATOR) && is_file($file)) return false;
http_response_code(404);
echo 'Page introuvable';
return true;
